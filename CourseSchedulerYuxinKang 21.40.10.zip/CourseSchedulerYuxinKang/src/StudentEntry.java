/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author mac
 */
public class StudentEntry {
    private String studentID;
    private String firstname;
    private String lastname;
    
    public StudentEntry(String studentID, String firstname, String lastname){
        this.studentID = studentID;
        this.firstname = firstname;
        this.lastname = lastname;
    }

    public String getStudentID() {
        return studentID;
    }

    public String getFirstname() {
        return firstname;
    }

    public String getLastname() {
        return lastname;
    }
    
    
    
}
