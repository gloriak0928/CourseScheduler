/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
/**
 *
 * @author mac
 */
public class ScheduleQueries {
    private static Connection connection;
    //private static ArrayList<ScheduleEntry> scheduleList = new ArrayList<ScheduleEntry>();
    private static PreparedStatement addScheduleEntry; 
    private static PreparedStatement getScheduleByStudent; 
    private static PreparedStatement getScheduledStudentCount;
    private static PreparedStatement getScheduledStudentsByCourse;
    private static PreparedStatement getWaitlistedStudentsByCourse;
    private static PreparedStatement dropStudentScheduleByCourse;
    private static PreparedStatement dropScheduleByCourse;
    private static PreparedStatement updateScheduleEntry;
    private static PreparedStatement dropCourseFromWaitlist;
    private static PreparedStatement dropNobodySelectedCourse;
    private static ResultSet resultSet;
    private static ResultSet waitlist;
    private static Integer count;
    
    public static void addScheduleEntry(ScheduleEntry entry){
        connection = DBConnection.getConnection();
        try{
            addScheduleEntry = connection.prepareStatement("insert into app.schedule (semester, studentID , coursecode, status, timestamp) values(?, ?, ?, ?, ?)");
            addScheduleEntry.setString(1, entry.getSemester());
            addScheduleEntry.setString(2, entry.getStudentID());
            addScheduleEntry.setString(3, entry.getCourseCode());
            addScheduleEntry.setString(4, entry.getStatus());
            addScheduleEntry.setTimestamp(5, entry.getTimestamp());
            addScheduleEntry.executeUpdate();
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
    }
    
    public static ArrayList getScheduleByStudent(String semester, String studentID){
        connection = DBConnection.getConnection();
        ArrayList<ScheduleEntry> scheduleList = new ArrayList<ScheduleEntry>();
        try{
           getScheduleByStudent= connection.prepareStatement("select * from app.schedule where semester = ? and studentID = ?");
           getScheduleByStudent.setString(1, semester);
           getScheduleByStudent.setString(2, studentID);
           resultSet = getScheduleByStudent.executeQuery();
           while (resultSet.next()){
               scheduleList.add(new ScheduleEntry(resultSet.getString(1), resultSet.getString(2), resultSet.getString(3), resultSet.getString(4), resultSet.getTimestamp(5)));
           }
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
        return scheduleList;
    }
        
    public static int getScheduledStudentCount(String currentSemester, String courseCode){
        connection = DBConnection.getConnection();
        
        try{
            getScheduledStudentCount= connection.prepareStatement("select count(studentID) from app.schedule where semester = ? and courseCode = ? and status = 'Scheduled'");
            getScheduledStudentCount.setString(1, currentSemester);
            getScheduledStudentCount.setString(2, courseCode);
            resultSet = getScheduledStudentCount.executeQuery();
            while(resultSet.next())
            {
                count = resultSet.getInt(1);
            }
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return count;
    }
    
    public static ArrayList getScheduledStudentsByCourse(String semester, String courseCode) {
        connection = DBConnection.getConnection();
        ArrayList<ScheduleEntry> scheduledStudentList = new ArrayList<>();
        try{
            getScheduledStudentsByCourse= connection.prepareStatement("select * from app.schedule where semester = ? and courseCode = ? and status = 'Scheduled' order by timestamp asc");
            getScheduledStudentsByCourse.setString(1, semester);
            getScheduledStudentsByCourse.setString(2, courseCode);
            resultSet = getScheduledStudentsByCourse.executeQuery();
            while (resultSet.next()){
               scheduledStudentList.add(new ScheduleEntry(resultSet.getString(1), resultSet.getString(2), resultSet.getString(3), "Scheduled", resultSet.getTimestamp(5)));
           }
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
        return scheduledStudentList;
    }
    
    public static ArrayList getWaitlistedStudentsByCourse(String semester, String courseCode){
        connection = DBConnection.getConnection();
        ArrayList<ScheduleEntry> waitlistedStudentList = new ArrayList<>();
        try{
            getWaitlistedStudentsByCourse= connection.prepareStatement("select * from app.schedule where semester = ? and courseCode = ? and status = 'Waitlisted' order by timestamp asc");
            getWaitlistedStudentsByCourse.setString(1, semester);
            getWaitlistedStudentsByCourse.setString(2, courseCode);
            waitlist = getWaitlistedStudentsByCourse.executeQuery();
            while (waitlist.next()){
            waitlistedStudentList.add(new ScheduleEntry(waitlist.getString(1), waitlist.getString(2), waitlist.getString(3), "Waitlisted", waitlist.getTimestamp(5)));
            //System.out.print(waitlistedStudentList);
           }
            for(ScheduleEntry e: waitlistedStudentList){
//                 System.out.print(e.getStudentID());
                
            }
           
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
        return waitlistedStudentList;
    }
    
    public static void dropStudentScheduleByCourse(String semester, String studentID, String courseCode){
        connection = DBConnection.getConnection();
        try{
            dropStudentScheduleByCourse = connection.prepareStatement("delete from app.schedule where (semester = ?) and (studentID = ?) and (courseCode = ?)");
            dropStudentScheduleByCourse.setString(1, semester);
            dropStudentScheduleByCourse.setString(2, studentID);
            dropStudentScheduleByCourse.setString(3, courseCode);
            dropStudentScheduleByCourse.executeUpdate();
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
    }
    
    public static void dropScheduleByCourse(String semester, String courseCode){
        connection = DBConnection.getConnection();
        try{
            dropScheduleByCourse = connection.prepareStatement("delete from app.schedule where semester = ? and courseCode = ?");
            dropScheduleByCourse.setString(1, semester);
            dropScheduleByCourse.setString(2, courseCode);
            dropScheduleByCourse.executeUpdate();
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
    }
    
    public static void updateScheduleEntry(String semester, ScheduleEntry entry){
        connection = DBConnection.getConnection();
        try{
            updateScheduleEntry = connection.prepareStatement("update app.schedule set status = 'Scheduled' where semester = ? and studentid = ? and coursecode = ?");
            updateScheduleEntry.setString(1, semester);
            updateScheduleEntry.setString(2, entry.getStudentID());
            updateScheduleEntry.setString(3, entry.getCourseCode());
            updateScheduleEntry.executeUpdate();
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
    }
    
    public static void dropCourseFromWaitlist(String semester,String studentID, String courseCode, String status){
        connection = DBConnection.getConnection();
        try{
            dropCourseFromWaitlist = connection.prepareStatement("delete from app.schedule where semester = ? and studentID = ? and courseCode = ? and status = 'Waitlisted'");
            dropCourseFromWaitlist.setString(1, semester);
            dropCourseFromWaitlist.setString(2, studentID);
            dropCourseFromWaitlist.setString(3, courseCode);
            dropCourseFromWaitlist.executeUpdate();
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
    }
    
    public static void dropNobodySelectedCourse(String semester, String courseCode){
        connection = DBConnection.getConnection();
        try{
            dropNobodySelectedCourse = connection.prepareStatement("delete from app.course where semester = ? and courseCode = ?");
            dropNobodySelectedCourse.setString(1, semester);
            dropNobodySelectedCourse.setString(2, courseCode);
            dropNobodySelectedCourse.executeUpdate();
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
    }
}
  