/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author mac
 */


public class CourseEntry {
    private String semester;
    private String coursecode;
    private String description;
    private int seats;
    
    public CourseEntry(String semester, String coursecode, String description, int seats){
        this.semester = semester;
        this.coursecode = coursecode;
        this.description = description;
        this.seats = seats;
    }

    public String getSemester() {
        return semester;
    }

    public String getCoursecode() {
        return coursecode;
    }

    public String getDescription() {
        return description;
    }

    public int getSeats() {
        return seats;
    }
    

    
}
