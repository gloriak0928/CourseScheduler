
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author mac
 */
public class CourseQueries {
    private static Connection connection;
    //private static ArrayList<CourseEntry> courseList = new ArrayList<CourseEntry>();
    //private static ArrayList<String> courseCodesList = new ArrayList<String>();
    private static PreparedStatement getAllCourses;
    private static PreparedStatement addCourse;
    private static PreparedStatement getAllCourseCodes;
    private static PreparedStatement getCourseSeats;
    private static PreparedStatement dropCourse;
//    private static PreparedStatement dropCourseForStudent;
    private static ResultSet resultSet;
    
    public static ArrayList getAllCourses(String semester)
    {
        connection = DBConnection.getConnection();
        ArrayList<CourseEntry> courseList = new ArrayList<CourseEntry>();
        try
        {
        getAllCourses = connection.prepareStatement("select * from app.course where semester = ?");
        //System.out.print(semester); 
        getAllCourses.setString(1, semester);
        resultSet = getAllCourses.executeQuery();
            while (resultSet.next())
            {
                CourseEntry entry = new CourseEntry(
                        resultSet.getString(1), 
                        resultSet.getString(2), 
                        resultSet.getString(3), 
                        resultSet.getInt(4));
                courseList.add(entry);
                //System.out.print(entry); 
//                System.out.print(resultSet.getString(1)); 
//                System.out.print(resultSet.getString(2));
//                System.out.print(resultSet.getString(3));
//                System.out.print(resultSet.getInt(4));
//                        
            }    
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return courseList;
    }
    
    public static void addCourse(CourseEntry course){
        connection = DBConnection.getConnection();
        try{
            addCourse = connection.prepareStatement("insert into app.course (semester, coursecode, description, seats) values(?, ?, ?, ?)");
            addCourse.setString(1, course.getSemester());
            addCourse.setString(2, course.getCoursecode());
            addCourse.setString(3, course.getDescription());
            addCourse.setInt(4, course.getSeats());
            addCourse.executeUpdate();
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
    }
    
    public static ArrayList getAllCourseCodes(String semester){
        connection = DBConnection.getConnection();
        ArrayList<String> courseCodesList = new ArrayList<String>();
        try{
            getAllCourseCodes= connection.prepareStatement("select CourseCode from app.Course");
            resultSet =  getAllCourseCodes.executeQuery();
            while (resultSet.next()){
                courseCodesList.add(resultSet.getString(2));
            }
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return courseCodesList;
    }
    
    public static int getCourseSeats(String semester, String courseCode){
        connection = DBConnection.getConnection();
        int seats = -1;
        try{
            getCourseSeats = connection.prepareStatement("select * from app.Course where semester = ? and coursecode = ?");
            getCourseSeats.setString(1, semester);
            getCourseSeats.setString(2, courseCode);
            resultSet =  getCourseSeats.executeQuery();
            while (resultSet.next()){
                seats = resultSet.getInt("seats");
            }
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return seats;
    }
    
    public static void dropCourse(String semester, String courseCode){
        connection = DBConnection.getConnection();
        try{
            dropCourse = connection.prepareStatement("delete from app.course where semester = ? and courseCode = ?");
            dropCourse.setString(1, semester);
            dropCourse.setString(2, courseCode);
            dropCourse.executeUpdate();
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
    }
//    public static void dropCourseForStudent(String semester,String studentID, String courseCode){
//        connection = DBConnection.getConnection();
//        try{
//            dropCourseForStudent = connection.prepareStatement("delete from app.schedule where semester = ? and studentID = and courseCode = ?");
//            dropCourseForStudent.setString(1, semester);
//            dropCourseForStudent.setString(2, studentID);
//            dropCourseForStudent.setString(3, courseCode);
//            dropCourseForStudent.executeUpdate();
//        }
//        catch(SQLException sqlException)
//        {
//            sqlException.printStackTrace();
//        }
//    }
}
